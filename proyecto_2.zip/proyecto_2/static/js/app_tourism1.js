var url = "/api/tourism";
xl =[];
yl = [];
yl2=[];
    //data= [t1]
    d3.json(url).then(function(data){
        var cuenta=Object.keys(data).length;
    for (var i=0; i< cuenta; i++){
        xl.push(data[i].mes)
        yl.push(data[i].ingresos_totales)
        yl2.push(data[i].ingresos_totales_2019)}
        let EPN ={
            x: xl, 
            y: yl}
        let AMLO ={
            x: xl, 
            y: yl2}
        var layout={
            title: "Tourism influx",
            xaxis:{
                title: "Month"
            },
            yaxis: {
                title:"Amount of tourists (national and foreign)"
            }
        };
        Plotly.plot(document.getElementById('plot'), [EPN, AMLO], layout);})