var url = "/api/jobs";
mes =[];
EPN = [];
AMLO=[];
    //data= [t1]
    d3.json(url).then(function(data){
        var cuenta=Object.keys(data).length;
    for (var i=0; i< cuenta; i++){
        mes.push(data[i].mes)
        EPN.push(data[i].generacion_empleos_mensuales_2018)
        AMLO.push(data[i].generacion_empleos_mensuales_2019)}
        let trace1 ={
            x: mes, 
            y: EPN}
        let trace2 ={
            x: mes, 
            y: AMLO}
        var layout={
            title: "Jobs Created",
            xaxis:{
                title: "Month"
            },
            yaxis: {
                title:"Number of jobs created per month "
            }
        };
        Plotly.plot(document.getElementById('plot'), [trace1, trace2], layout);})