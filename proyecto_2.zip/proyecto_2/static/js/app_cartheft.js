var url = "/api/cartheft";
mes =[];
EPN = [];
AMLO=[];
    //data= [t1]
    d3.json(url).then(function(data){
        var cuenta=Object.keys(data).length;
    for (var i=0; i< cuenta; i++){
        mes.push(data[i].mes)
        EPN.push(data[i].robos_2018)
        AMLO.push(data[i].robos_2019)}
        let trace1 ={
            x: mes, 
            y: EPN}
        let trace2 ={
            x: mes, 
            y: AMLO}
        var layout={
            title: "Car theft",
            xaxis:{
                title: "Month"
            },
            yaxis: {
                title:"Number of stolen cars "
            }
        };
        Plotly.plot(document.getElementById('plot'), [trace1, trace2], layout);})