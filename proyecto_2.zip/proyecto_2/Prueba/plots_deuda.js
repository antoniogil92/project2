var trace1= {
    x: ["Trimestre 1 - 2018", "Trimestre 2 - 2018", "Trimestre 3 - 2018", "Trimestre 4 - 2018", "Trimestre 1 - 2019"],
    y: [10024150, 10532774, 10366833, 10829907, 10846682],
    name:"Monto de deuda pública",
    type: 'lines+scatter',
    color: 'green'
  };
  var data = [trace1];
  
  var layout = {
    title: "Deuda Pública"
  };
  
  Plotly.newPlot("plot5", data, layout);