var trace1= {
    x: ["Trimestre 1 - 2018", "Trimestre 2 - 2018", "Trimestre 3 - 2018", "Trimestre 4 - 2018", "Trimestre 1 - 2019"],
    y: [18526328, 18455379, 18578761, 18584926 , 18552607],
    name:"Monto en mdp",
    type: 'lines+scatter',
    color: 'green'
  };
  var data = [trace1];
  
  var layout = {
    title: "Crecimiento del PIB"
  };
  
  Plotly.newPlot("plot6", data, layout);