var trace1= {
    x: ["Enero", "Febrero", "Marzo ", "Abril"],
    y: [8363220,8026778,9307622,8317776],
    name:"EPN - 2018",
    type: 'bar',
    color: 'green'
  };
  var trace2= {
      x: ["Enero", "Febrero", "Marzo ", "Abril"],
      y: [7923897,7662663,9041840,8073855],
      name:"AMLO - 2019",
      type: 'bar',
      color: 'red'
    };
  
  var data = [trace1, trace2];
  
  var layout = {
    title: "Ingresos turísticos - nacional e internacional"
  };
  
  Plotly.newPlot("plot5", data, layout);