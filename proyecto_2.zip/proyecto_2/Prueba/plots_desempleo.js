var trace1= {
    x: ["Enero", "Febrero", "Marzo ", "Abril"],
    y: [3.3, 3.3, 3.2, 3.4],
    name:"EPN - 2018",
    type: 'lines+markers',
    color: 'green'
  };
  var trace2= {
      x: ["Enero", "Febrero", "Marzo ", "Abril", "Mayo"],
      y: [3.5, 3.4, 3.6, 3.5],
      name:"AMLO - 2019",
      type: 'lines+markers',
      color: 'red'
    };
  
  var data = [trace1, trace2];
  
  var layout = {
    title: "Desempleo"
  };
  
  Plotly.newPlot("plot2", data, layout);
  