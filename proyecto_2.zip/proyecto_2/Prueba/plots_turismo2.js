var trace1= {
    x: ["Enero", "Febrero", "Marzo ", "Abril"],
    y: [8363220,16389998,25697620,34015396],
    name:"EPN - 2018",
    type: 'bar',
    color: 'green'
  };
  var trace2= {
      x: ["Enero", "Febrero", "Marzo ", "Abril"],
      y: [7923897,15586560,24628400,32702255],
      name:"AMLO - 2019",
      type: 'bar',
      color: 'red'
    };
  
  var data = [trace1, trace2];
  
  var layout = {
    title: "Acumulado mensual de ingresos turísticos"
  };
  
  Plotly.newPlot("plot6", data, layout);