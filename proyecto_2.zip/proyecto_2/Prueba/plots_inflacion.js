var trace1= {
  x: ["Enero", "Febrero", "Marzo ", "Abril", "Mayo"],
  y: [3.38, 3.24, 3.64, 4, 5.41],
  name:"EPN - 2018",
  type: 'lines+markers',
  color: 'green'
};
var trace2= {
    x: ["Enero", "Febrero", "Marzo ", "Abril", "Mayo"],
    y: [4.97, 4.52, 4.25, 4.63, 3.18],
    name:"AMLO - 2019",
    type: 'lines+markers',
    color: 'red'
  };

var data = [trace1, trace2];

var layout = {
  title: "Inflación"
};

Plotly.newPlot("plot", data, layout);
