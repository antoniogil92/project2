var trace1= {
    x: ["Enero", "Febrero", "Marzo ", "Abril", "Mayo"],
    y: [113722, 278033, 368542, 455651, 489617],
    name:"EPN - 2018",
    type: 'lines+markers',
    color: 'green'
  };
  var trace2= {
      x: ["Enero", "Febrero", "Marzo ", "Abril", "Mayo"],
      y: [94646, 220628, 269143, 299562, 303545],
      name:"AMLO - 2019",
      type: 'lines+markers',
      color: 'red'
    };
  
  var data = [trace1, trace2];
  
  var layout = {
    title: "Empleos generados acumulados en el año"
  };
  
  Plotly.newPlot("plot4", data, layout);