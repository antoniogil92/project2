var trace1= {
    x: ["Enero", "Febrero", "Marzo ", "Abril", "Mayo"],
    y: [113722, 164311, 90509, 87109, 33966],
    name:"EPN - 2018",
    type: 'lines+markers',
    color: 'green'
  };
  var trace2= {
      x: ["Enero", "Febrero", "Marzo ", "Abril", "Mayo"],
      y: [94646, 125982, 48515, 30419, 3983],
      name:"AMLO - 2019",
      type: 'lines+markers',
      color: 'red'
    };
  
  var data = [trace1, trace2];
  
  var layout = {
    title: "Empleos Formales Generados en el Mes"
  };
  
  Plotly.newPlot("plot3", data, layout);
  