from sqlalchemy import func, create_engine
import pandas as pd
from flask import (
    Flask,
    render_template,
    jsonify,
    request,
    redirect)

from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

db=SQLAlchemy(app)

engine = create_engine("mysql+mysqldb://root:Sweater1693@localhost/db2018?charset=utf8")

conn=engine.connect()

class unemployement(db.Model):
    __tablename__ = 'unemployement'

    id = db.Column(db.Integer, primary_key=True)
    mes = db.Column(db.String)
    porcentaje = db.Column(db.Float)

    def __repr__(self):
        return '<unemployement %r>' % (self.name)

class unemployement2019(db.Model):
    __tablename__ = 'unemployement2019'

    id = db.Column(db.Integer, primary_key=True)
    mes = db.Column(db.String)
    porcentaje = db.Column(db.Float)

    def __repr__(self):
        return '<unemployement2019 %r>' % (self.name)

class jobs_created(db.Model):
    __tablename__ = 'jobs_created'

    id = db.Column(db.Integer, primary_key=True)
    mes = db.Column(db.String)
    empleo_formales_totales = db.Column(db.Integer)
    generación_empleo_mensual = db.Column(db.Integer)
    generación_empleo_acumulado = db.Column(db.Integer)

    def __repr__(self):
        return '<jobs_created %r>' % (self.name)

class jobs_created_2019(db.Model):
    __tablename__ = 'jobs_created_2019'

    id = db.Column(db.Integer, primary_key=True)
    mes = db.Column(db.String)
    empleo_formales_totales = db.Column(db.Integer)
    generación_empleo_mensual = db.Column(db.Integer)
    generación_empleo_acumulado = db.Column(db.Integer)

    def __repr__(self):
        return '<jobs_created_2019 %r>' % (self.name)

class homicidios(db.Model):
    __tablename__ = 'homicidios'

    id = db.Column(db.Integer, primary_key=True)
    entidad = db.Column(db.String)
    municipio = db.Column(db.String)    
    enero = db.Column(db.Integer)
    febrero = db.Column(db.Integer)
    marzo = db.Column(db.Integer)
    abril = db.Column(db.Integer)
    
    def __repr__(self):
        return '<homicidios %r>' % (self.name)

class homicidios2019(db.Model):
    __tablename__ = 'homicidios2019'

    id = db.Column(db.Integer, primary_key=True)
    entidad = db.Column(db.String)
    municipio = db.Column(db.String)    
    enero = db.Column(db.Integer)
    febrero = db.Column(db.Integer)
    marzo = db.Column(db.Integer)
    abril = db.Column(db.Integer)
    
    def __repr__(self):
        return '<homicidios2019 %r>' % (self.name)

class inflation(db.Model):
    __tablename__ = 'inflation'

    id = db.Column(db.Integer, primary_key=True)
    mes = db.Column(db.String)
    variacion = db.Column(db.Integer)

    def __repr__(self):
        return '<inflation %r>' % (self.name)

class inflation2019(db.Model):
    __tablename__ = 'inflation2019'

    id = db.Column(db.Integer, primary_key=True)
    mes = db.Column(db.String)
    variacion = db.Column(db.Integer)

    def __repr__(self):
        return '<inflation2019 %r>' % (self.name)

class robo_casa(db.Model):
    __tablename__ = 'robo_casa'

    id = db.Column(db.Integer, primary_key=True)    
    entidad = db.Column(db.String)
    municipio = db.Column(db.String)    
    enero = db.Column(db.Integer)
    febrero = db.Column(db.Integer)
    marzo = db.Column(db.Integer)
    abril = db.Column(db.Integer)
    

    def __repr__(self):
        return '<robo_casa %r>' % (self.name)

class robo_casa_2019(db.Model):
    __tablename__ = 'robo_casa_2019'

    id = db.Column(db.Integer, primary_key=True)    
    entidad = db.Column(db.String)
    municipio = db.Column(db.String)    
    enero = db.Column(db.Integer)
    febrero = db.Column(db.Integer)
    marzo = db.Column(db.Integer)
    abril = db.Column(db.Integer)
    

    def __repr__(self):
        return '<robo_casa_2019 %r>' % (self.name)

class robo_transeunte(db.Model):
    __tablename__ = 'robo_transeunte'

    id = db.Column(db.Integer, primary_key=True)
    entidad = db.Column(db.String)
    municipio = db.Column(db.String)    
    enero = db.Column(db.Integer)
    febrero = db.Column(db.Integer)
    marzo = db.Column(db.Integer)
    abril = db.Column(db.Integer)

    def __repr__(self):
        return '<robo_transeunte %r>' % (self.name)

class robo_transeunte_2019(db.Model):
    __tablename__ = 'robo_transeunte_2019'

    id = db.Column(db.Integer, primary_key=True)
    entidad = db.Column(db.String)
    municipio = db.Column(db.String)    
    enero = db.Column(db.Integer)
    febrero = db.Column(db.Integer)
    marzo = db.Column(db.Integer)
    abril = db.Column(db.Integer)

    def __repr__(self):
        return '<robo_transeunte_2019 %r>' % (self.name)

class robo_transporte(db.Model):
    __tablename__ = 'robo_transporte'

    id = db.Column(db.Integer, primary_key=True)
    entidad = db.Column(db.String)
    municipio = db.Column(db.String)    
    enero = db.Column(db.Integer)
    febrero = db.Column(db.Integer)
    marzo = db.Column(db.Integer)
    abril = db.Column(db.Integer)

    def __repr__(self):
        return '<robo_transporte %r>' % (self.name)

class robo_transporte_2019(db.Model):
    __tablename__ = 'robo_transporte_2019'

    id = db.Column(db.Integer, primary_key=True)
    entidad = db.Column(db.String)
    municipio = db.Column(db.String)    
    enero = db.Column(db.Integer)
    febrero = db.Column(db.Integer)
    marzo = db.Column(db.Integer)
    abril = db.Column(db.Integer)

    def __repr__(self):
        return '<robo_transporte_2019 %r>' % (self.name)

class robo_vehiculos(db.Model):
    __tablename__ = 'robo_vehiculos'

    id = db.Column(db.Integer, primary_key=True)
    entidad = db.Column(db.String)
    municipio = db.Column(db.String)    
    enero = db.Column(db.Integer)
    febrero = db.Column(db.Integer)
    marzo = db.Column(db.Integer)
    abril = db.Column(db.Integer)
    
    def __repr__(self):
        return '<robo_vehiculos %r>' % (self.name)

class robo_vehiculos_2019(db.Model):
    __tablename__ = 'robo_vehiculos_2019'

    id = db.Column(db.Integer, primary_key=True)
    entidad = db.Column(db.String)
    municipio = db.Column(db.String)    
    enero = db.Column(db.Integer)
    febrero = db.Column(db.Integer)
    marzo = db.Column(db.Integer)
    abril = db.Column(db.Integer)
    
    def __repr__(self):
        return '<robo_vehículos_2019 %r>' % (self.name)

class tourism(db.Model):
    __tablename__ = 'tourism'

    id = db.Column(db.Integer, primary_key=True)
    mes = db.Column(db.String)
    ingresos_totales = db.Column(db.Integer)
    ingresos_acumulados_mes = db.Column(db.Integer)

    def __repr__(self):
        return '<tourism %r>' % (self.name)

class tourism2019(db.Model):
    __tablename__ = 'tourism2019'

    id = db.Column(db.Integer, primary_key=True)
    mes = db.Column(db.String)
    ingresos_totales = db.Column(db.Integer)
    ingresos_acumulados_mes = db.Column(db.Integer)

    def __repr__(self):
        return '<tourism2019 %r>' % (self.name)


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/economy")
def desempleotrace():
    results1 = pd.read_sql("SELECT * FROM db2018.unemployement")
    results2= pd.read_sql("SELECT * FROM db2018.unemployment2019")
    results1=results1.to_json(orient="index")
    results2=results2.to_json(orient="index")

    trace12 = {
        "x": unemployement.mes,
        "y": unemployement.porcentaje,
        'name': "EPN - 2018",
        "type": "scatter",
        "mode": "lines",
        "color": 'green'
    }

    trace21 = {
        "x": unemployement2019.mes,
        "y": unemployement2019.porcentaje,
        'name': "AMLO - 2019",
        "type": "scatter",
        "mode": "lines",
        "color": 'red'
    }

    return render_template('index.html',results1=results1, results2=results2)

