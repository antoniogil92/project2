import sqlalchemy
import logging
from sqlalchemy.ext.automap import automap_base
from sqlalchemy import create_engine, inspect
from bs4 import BeautifulSoup as bs 
from splinter import browser
from selenium import webdriver
import os
import requests
import pandas as pd
from flask import Flask, render_template, jsonify, request, redirect

from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

db=SQLAlchemy(app)

engine = create_engine('mysql://root:Sweater1693@localhost/db2018?charset=utf8')

conn=engine.connect()

@app.route("/")
def home():

    return render_template('index.html')

@app.route("/api/unemployement")
def desempleotrace():

    results1 = pd.read_sql("SELECT * FROM unemployement", conn)
    results1 = results1.to_json(orient="index")

    return (results1)

@app.route("/api/inflation")
def inflationtrace():

    results2 = pd.read_sql("SELECT * FROM inflation", conn)
    results2 = results2.to_json(orient="index")

    return (results2)

@app.route("/api/tourism")
def tourismtrace():

    results3 = pd.read_sql("SELECT * FROM tourism", conn)
    results3 = results3.to_json(orient="index")

    return (results3)

@app.route("/api/jobs")
def jobstrace():

    results4 = pd.read_sql("SELECT * FROM jobs_created", conn)
    results4 = results4.to_json(orient="index")

    return (results4)

app.route("/api/robohab")
def housetheft():

    results5 = pd.read_sql("SELECT * FROM robo_casa", conn)
    results5 = results5.to_json(orient="index")

    return (results5)

app.route("/api/trans")
def jobspasserby():

    results6 = pd.read_sql("SELECT * FROM robo_transeunte", conn)
    results6 = results6.to_json(orient="index")

    return (results6)

app.route("/api/transport")
def jobstransport():

    results7 = pd.read_sql("SELECT * FROM robo_transporte", conn)
    results7 = results7.to_json(orient="index")

    return (results7)

app.route("/api/cartheft")
def jobstransport():

    results8 = pd.read_sql("SELECT * FROM robo_vehículos", conn)
    results8 = results8.to_json(orient="index")

    return (results8)

app.route("/api/homicide")
def jobstransport():

    results9 = pd.read_sql("SELECT * FROM homicidios", conn)
    results9 = results8.to_json(orient="index")

    return (results9)

app.route("/api/highjacking")
def jobstransport():

    results10 = pd.read_sql("SELECT * FROM secuestros", conn)
    results10 = results8.to_json(orient="index")

    return (results10)


if __name__ == '__main__':
   app.run(debug=True)